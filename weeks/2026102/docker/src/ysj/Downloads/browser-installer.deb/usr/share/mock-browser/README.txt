Mock browser payload.
